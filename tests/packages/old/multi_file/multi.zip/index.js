var mid = require("mid.js");
function enter(input) {
  var middle = input + "test";
  mid.foo(middle);
}

module.exports = {
  enter: enter
}
