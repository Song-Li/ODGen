var end = require("end.js");
function mid(input) {
  var to_end = input + "test1";
  end.end(to_end);
}

module.exports = {
  foo: mid
}
