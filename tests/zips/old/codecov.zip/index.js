var handleInput = require('./lib/codecov')

exports.handleInput = handleInput
