'use strict'

class BeaconError extends Error {}

module.exports = BeaconError
