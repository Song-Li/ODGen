'use strict';

var Confucious = require('./confucious');

module.exports = new Confucious();