
3.3.0 / 2017-05-19
==================

  * feat: support options.multiArgs and options.withCallback (#27)
